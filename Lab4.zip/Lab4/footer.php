<footer>
	<div id="copyright">Copyright 2018 Daniel Wikström hej</div>
</footer>