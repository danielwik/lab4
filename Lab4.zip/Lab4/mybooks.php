
<!DOCTYPE html>
<html>
<head>
	<title>Books</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
</head>
<body>
<?php include("header.php");?>
	<main>
 

<?php
	
	/* connecting the database to the site */
	@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);


	if($db->connect_error){
		echo "Couldn't connect, this is why:" . $db->connect_error;
		exit();
	}

	if(isset($_GET["reserved"])){
		$bookID = $_GET["reserved"];
		$sql = "UPDATE books SET reserved= '0' WHERE id= '$bookID'";
		$stmt = $db->prepare($sql);
		$stmt->execute();

	}
	/* Checks if the "submit" button is clicked 
	and if something is written in the forms 

	finds the form method post and the ID of the input and uses the value
	*/


	$query = "SELECT books.id, books.title, books.isbn, books.edition, books.reserved, authors.first_name, authors.last_name FROM books
		JOIN authors_books ON books.id = authors_books.book_id
		JOIN authors ON authors.id = authors_books.author_id
		WHERE reserved=1";

/* this lists the results in the different $ */
	$stmt = $db->prepare($query);
	$stmt->bind_result($bookID, $title, $edition, $isbn, $reserved, $authorF, $authorL);
	$stmt->execute();

/*  update the page and have a function that checks if the button was pressed, and if thats the case check the button which bookID was used and update the database value of reserved*/ 
 
	/* while stmt is something skriv ut resultatet*/
	while($stmt->fetch()){
		echo $bookID."</br>";
		echo "<b>Title</b>:  ". $title."</br>";
		echo "<b>ISBN</b>:  ". $isbn."</br>";
		echo "<b>Edition</b>:  ". $edition."</br>";
		echo "<b>Reserved</b>:  ". $reserved."</br>";
		echo "<b>First Name</b>:  ". $authorF."</br>";
		echo "<b>Last Name</b>:  ". $authorL."</br>";
		echo "
			<form action='' method='GET'>
				<button name='reserved' value='".$bookID."''>Return</button>
			</form></br>";
		echo "</br>";
	}

?>

	</main>

<?php include("footer.php");?>



</body>
</html>