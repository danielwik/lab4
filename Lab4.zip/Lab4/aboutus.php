
<!DOCTYPE html>
<html>
<head>
	<title>Books</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
</head>
<body>
<?php include("header.php");?>
	<main>
		<div id="personholder">
			<div id="person1">
				<figure><img src="images/avatar1.png"></figure>
				<div>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				</div>
			</div>

			<div id="person2">
				<figure><img src="images/avatar2.png"></figure>
				<div>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				</div>
			</div>
		</div>
	</main>

<?php include("footer.php");?>




</body>
</html>