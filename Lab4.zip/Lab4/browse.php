
<?php

	include("header.php");
	
	/* connecting the database to the site */
	@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);


	if($db->connect_error){
		echo "Couldn't connect, this is why:" . $db->connect_error;
		exit();
	}

	if(isset($_GET["reserved"])){
		$bookID = $_GET["reserved"];
		$sql = "UPDATE books SET reserved= '1' WHERE id= '$bookID'";
		$stmt = $db->prepare($sql);
		$stmt->execute();

	}
	/* Checks if the "submit" button is clicked 
	and if something is written in the forms 

	finds the form method post and the ID of the input and uses the value
	*/

	$searchauthor = "";
	$searchtitle = "";

	if (isset($_POST) && !empty($_POST)){

	/*finds the form method post and the ID of the input and uses the value
	trim removes any spaces before or after the search*/

		$searchauthor = trim($_POST['author']);
		$searchtitle = trim($_POST['title']);

	}

	$query = "SELECT books.id, books.title, books.isbn, books.edition, books.reserved, authors.first_name, authors.last_name FROM books
		JOIN authors_books ON books.id = authors_books.book_id
		JOIN authors ON authors.id = authors_books.author_id
		AND reserved=0";


	if ($searchtitle && !$searchauthor){
		$query = $query . " WHERE books.title LIKE '%" . $searchtitle . "%' ";
	}
	if (!$searchtitle && $searchauthor){
		$query = $query . " WHERE authors.first_name LIKE '%" . $searchauthor . "%' OR authors.last_name LIKE '%" . $searchauthor . "%'";
	}
	if ($searchtitle && $searchauthor){
		$query = $query . " WHERE books.title LIKE '%" . $searchtitle . "%' AND authors.first_name LIKE '%" . $searchauthor . "%' OR authors.last_name LIKE '%" . $searchauthor . "%'";
	}

/* this lists the results in the different $ */
	$stmt = $db->prepare($query);
	$stmt->bind_result($bookID, $title, $edition, $isbn, $reserved, $authorF, $authorL);
	$stmt->execute();

/*  update the page and have a function that checks if the button was pressed, and if thats the case check the button which bookID was used and update the database value of reserved*/ 
?>



<!DOCTYPE html>
<html>
<head>
	<title>Books</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
</head>
<body>
	<main>
		<div id="formdiv">
			<form action="" method="post">
				<input type="text" id="author" name="author" placeholder="Author"></br>
				<input type="text" id="title" name="title" placeholder="Title"></br>
				<button type="submit"> Search </button>
			</form>
		</div>
		<div>
<?php  
	/* while stmt is something skriv ut resultatet*/
	while($stmt->fetch()){
		echo $bookID."</br>";
		echo "<b>Title</b>:  ". $title."</br>";
		echo "<b>ISBN</b>:  ". $isbn."</br>";
		echo "<b>Edition</b>:  ". $edition."</br>";
		echo "<b>Reserved</b>:  ". $reserved."</br>";
		echo "<b>First Name</b>:  ". $authorF."</br>";
		echo "<b>Last Name</b>:  ". $authorL."</br>";
		echo "
			<form action='' method='GET'>
				<button name='reserved' value='".$bookID."''>Reserve</button>
			</form></br>";
		echo "</br>";
	}

?>
</div>



	</main>
<?php include("footer.php");?>





</body>
</html>