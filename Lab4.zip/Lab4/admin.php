
<!DOCTYPE html>
<html>
<head>

	<title>Books</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
</head>
<body>
<?php include("../adminheader.php");?>
	<main>

		<h2 id="hej">
			Admin Page
		</h2><!---
		 <form action="upload.php" method="post" enctype="multipart/form-data">
   	 Select image to upload:
   	 <input type="file" name="fileToUpload" id="fileToUpload">
   	 <input type="submit" value="Upload Image" name="submit">
</form>
 -->
		<form id="fileuploadform" method="post" enctype="multipart/form-data">
			<input type="file" name="fileupload" id="fileupload">
			<button type="submit" value="Upload" name="upload">Upload</button>
		</form>

<?php

	if(isset($_FILES["fileupload"])){

	$upload = 1;
	$error = array();
	$target_dir = "uploads/";
	$fileuploadnow = $target_dir . basename($_FILES["fileupload"]["name"]);
//	$allowedextensions = array('jpg', 'jpeg', 'gif', 'png');
	$extension = strtolower(substr($_FILES['fileupload']['name'], strpos($_FILES['fileupload']['name'], '.') + 1));
	
	if($extension != "jpg" && $extension != "jpeg" && $extension != "png"){
   		array_push($error, 'Wrong filetype, you can only upload jpg, jpeg or png');
    	$upload = 0;
	}

	if ($_FILES['fileupload']['size'] > 2000000){
		array_push($error, 'File too big, maximum 2mb');
		$upload = 0;
	}

	if($upload === 0){
		print_r($error);
	}else{
		if(move_uploaded_file($_FILES['fileupload']['tmp_name'], $fileuploadnow)){
			//chmod($target_dir, 0755);
			//echo "your file is uploaded";
			header("location: gallery.php");
			}
		}
	}

?>

	</main>
<?php include("footer.php");?>



</body>
</html>