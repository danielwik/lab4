<?php 


$dbserver = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'Library';


$current_page = explode('/', $_SERVER['REQUEST_URI']);
$current_page = end($current_page);


/*
ini_set('session.cookie_httponly', true);

$comment= htmlentities($comment);
$comment = mysql_real_escape_string($db, $comment);

if ($_SESSION['userip'] !== $_SERVER['REMOTE_ADDR']){
	session_unset();
    session_destroy();
}
*/


 ?>