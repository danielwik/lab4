<?php

	include("header.php");
	
	/* connecting the database to the site */
	@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);


	if($db->connect_error){
		echo "Couldn't connect, this is why:" . $db->connect_error;
		exit();
	}

	$searchuser = "";
	$searchpw = "";

	if (isset($_POST) && !empty($_POST)){

	/*finds the form method post and the ID of the input and uses the value
	trim removes any spaces before or after the search*/

		$searchuser = trim($_POST['userName']);
		$searchpw = $_POST['password'];

		$searchuser = mysqli_real_escape_string($db,$searchuser);
		$searchpw = mysqli_real_escape_string($db,$searchpw);

	}

	$query = "SELECT username, password
				FROM users
				WHERE username = '".$searchuser."'
				AND password = '".$searchpw."'";


	$stmt = $db->prepare($query);
	$stmt->bind_result($username, $password);
	$stmt->execute();

	$stmt->fetch();
					

					if ($username && $password){
						header("Location: admin.php");
					}else{
						echo "Wrong input";
					}


?>


<!DOCTYPE html>
<html>
<head>
	<title>Log In</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
</head>
<body>
	<main>
		<div id="formdiv">
			<form action="" method="post">
				<input type="text" id="userName" name="userName" placeholder="Username"></br>
				<input type="password" id="password" name="password" placeholder="Password"></br>
				<button type="submit">Log In</button>
			</form>

		</div>
		<div>
</div>



	</main>
<?php include("footer.php");?>
