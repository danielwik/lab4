
<!DOCTYPE html>
<html>
<head>

	<title>Books</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
</head>
<body>
<?php include("header.php");?>
	<main>

		<h2 id="hej">
			Jönköping Book Club
		</h2>
		<p id="mainP">
			Welcome to our fantastic book club, please sign up and enjoy your stay.
		</p>
	</main>
<?php include("footer.php");?>



</body>
</html>