
<!DOCTYPE html>
<html>
<head>

	<title>Books</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
</head>
<body>
<?php include("header.php");?>
	<main>

		<h2 id="hej">
			Gallery
		</h2>
		<div id="pictures">
			<?php

				 $dir = "uploads/*.*";
				 $images = glob($dir);

				 foreach($images as $image){  
				 	echo "<div class='imagediv'> <img src='" . $image . "'/> </div>";
				 }
				 
			 ?>
		</div>
	</main>
<?php include("footer.php");?>



</body>
</html>