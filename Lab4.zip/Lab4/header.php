<?php include("config.php");?>
<link href="https://fonts.googleapis.com/css?family=Dancing+Script:400,700" rel="stylesheet">
<header>
	<div id=header>
		<h1>
			<a href="index.php">Home</a>
		</h1>
		<nav>
			<ul id="topmenu">
				<li class="<?php echo ($current_page == 'aboutus.php') ? 'active' : NULL ?>">
					<a href="aboutus.php">About us</a>
				</li>
				<li class="<?php echo ($current_page == 'browse.php') ? 'active' : NULL ?>" >
					<a href="browse.php">Browse books</a>
				</li>

				<li class="<?php echo ($current_page == 'mybooks.php') ? 'active' : NULL ?>" >
					<a href="mybooks.php">My books</a>
				</li>

				<li class="<?php echo ($current_page == 'contact.php') ? 'active' : NULL ?>" >
					<a href="contact.php">Contact us</a>
				</li>
				<li class="<?php echo ($current_page == 'gallery.php') ? 'active' : NULL ?>" >
					<a href="gallery.php">Gallery</a>
				</li>
				<li class="<?php echo ($current_page == 'login.php') ? 'active' : NULL ?>" >
					<a href="login.php">Log In</a>
				</li>
			</ul>
		</nav>
	</div>
</header>